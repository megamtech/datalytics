import { FilterPipe } from "../_pipes/filter.pipe";
import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
} from "@angular/core";
import { IAngularMyDpOptions, IMyDateModel } from "angular-mydatepicker";
// import { ConstantService } from "src/app/_config/constants";

@Component({
  selector: "app-report-filters",
  templateUrl: "./report-filters.component.html",
  styleUrls: ["./report-filters.component.scss"],
})
export class ReportFiltersComponent implements OnInit, OnChanges {
  @Input() name: string;
  @Input() filters: any;
  @Input() inputSize: any;

  @Output() getFilterData = new EventEmitter<any>();

  // tslint:disable-next-line:variable-name
  filterData: any = {};
  filterDataArray: any = [];
  filterDropDown: any;
  filterTypes: {} = {
    text: ["contains", "contains"],
    number: ["gte", ">="],
    typeMultiSelect: ["in", "in"],
    typeSelect: ["equals", "="],
    dateRange: ["daterange", "between"],
  };
  filterDateOptions: IAngularMyDpOptions = {
    // other options...
    dateRange: true,
    disableUntil: { year: 0, month: 0, day: 0 },
    dateFormat: 'dd/mm/yyyy',
  };
  constructor(private filterPipe: FilterPipe) {}

  ngOnInit() {
    this.inputSize = this.inputSize ? this.inputSize : "col-3";
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.filters) {
      console.log("filters changed");
      console.log("11", changes.filters);
      this._setFiltersData(changes.filters.currentValue || []);
    }
  }
  _setFiltersData(data: any) {}
  search() {
    this.filterDataArray = [];
    let searchCondition = [];
    Object.keys(this.filterData).forEach((filter) => {
      const filterProp = this.filterPipe.transform(
        this.filters,
        "prop",
        filter
      )[0];
      searchCondition.push({
        column: filter,
        type: this.filterTypes[filterProp.filterType][0],
        value: this.filterData[filter],
      });
      this.filterDataArray.push({
        label: {
          value: this.filterData[filter],
          column: filterProp.name,
          type: this.filterTypes[filterProp.filterType][1],
        },
        value: {
          value: this.filterData[filter],
          column: filter,
          type: this.filterTypes[filterProp.filterType][0],
        },
      });
    });

    this.getFilterData.emit(searchCondition);
    this.filterDropDown.close();
  }
  isArray(data: any) {
    return Array.isArray(data);
  }
  implode(data: []) {
    return '"' + data.join('" , "') + '"';
  }
  clear() {
    this.filterData = {};
  }
}
