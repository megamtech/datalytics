import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-datalytics-angular',
  template: `
    <p>
      datalytics-angular works!
    </p>
  `,
  styles: [
  ]
})
export class DatalyticsAngularComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
