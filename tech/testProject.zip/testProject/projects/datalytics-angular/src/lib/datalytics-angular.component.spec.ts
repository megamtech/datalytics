import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatalyticsAngularComponent } from './datalytics-angular.component';

describe('DatalyticsAngularComponent', () => {
  let component: DatalyticsAngularComponent;
  let fixture: ComponentFixture<DatalyticsAngularComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatalyticsAngularComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatalyticsAngularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
