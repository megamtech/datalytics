import { NgModule } from '@angular/core';
// import { DatalyticsAngularComponent } from './datalytics-angular.component';
import { TabularReportComponent } from './tabular-report/tabular-report.component';
import { ReportFiltersComponent } from './report-filters/report-filters.component';
import { DatalyticsAngularComponent } from './datalytics-angular.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AngularMyDatePickerModule } from "angular-mydatepicker";
import { FilterPipe } from "./_pipes/filter.pipe";
import { NgSelectModule } from "@ng-select/ng-select";
@NgModule({
  declarations: [TabularReportComponent, ReportFiltersComponent, DatalyticsAngularComponent, FilterPipe],
  imports: [
    NgxDatatableModule,
    NgSelectModule,
    AngularMyDatePickerModule
  ],
  exports: [TabularReportComponent, ReportFiltersComponent, DatalyticsAngularComponent, FilterPipe]
})
export class DatalyticsAngularModule { }
