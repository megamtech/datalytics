/*
 * Public API Surface of datalytics-angular
 */

export * from './lib/datalytics-angular.service';
export * from './lib/datalytics-angular.component';
export * from './lib/report-filters/report-filters.component';
export * from './lib/tabular-report/tabular-report.component';
export * from './lib/datalytics-angular.module';
// export * from './lib/_pipes/filter.pipe';
